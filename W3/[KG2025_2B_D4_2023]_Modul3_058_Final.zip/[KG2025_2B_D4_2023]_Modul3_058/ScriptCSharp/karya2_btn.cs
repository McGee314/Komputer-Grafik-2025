using Godot;

public partial class BtnBack : Button
{
	public void OnBtnBackPressed()
	{
		var result = GetTree().ChangeSceneToFile("res://Scenes/Welcome.tscn");
		if (result != Error.Ok)
		{
			GD.Print("Scene Tidak Ada");
		}
	}
}
