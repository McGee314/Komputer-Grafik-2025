using Godot;
using System;

public partial class karya3 : Node2D
{
	public override void _Draw()
	{
		//DrawString(GD.Load<Font>("res://Assets/ANDYB.TTF"), new Vector2(100, 100), "Halo", new Color(1, 1, 1));
	}
}
