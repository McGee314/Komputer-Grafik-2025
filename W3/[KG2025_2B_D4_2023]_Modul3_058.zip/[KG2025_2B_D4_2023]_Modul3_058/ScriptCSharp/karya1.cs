namespace Godot;

using Godot;
using System;
using System.Collections.Generic;

public partial class karya1 : Node2D
{
	private primitif _primitif = new primitif();
	private bentukdasar _bentukdasar;

	
	private const int MarginLeft = 50;
	private const int MarginTop = 50;
	private const int WorldOriginX = 400; // Titik tengah world
	private const int WorldOriginY = 300;

	public override void _Ready()
	{
		GD.Print("karya1 _Ready() dipanggil");
		_bentukdasar = new bentukdasar();
		
		if (_bentukdasar == null)
			GD.PrintErr("ERROR: _bentukdasar masih null!");

		QueueRedraw();
	}


	public override void _Draw()
	{
		//DrawString(new Font(), new Vector2(100, 100), "Hello World", new Godot.Color(1, 1, 1);
		DrawShapes();
	}

	private void DrawShapes()
	{
		Godot.Color colorShape = new Godot.Color("#FF5733"); // Hijau untuk bentuk
		List<Vector2> persegi = _bentukdasar.Persegi(100, 100, 50);
		List<Vector2> persegiPanjang = _bentukdasar.PersegiPanjang(200, 100, 80, 40);
		//List<Vector2> segitiga = _bentukdasar.SegitigaSikuSiku(300, 100, 60, 60);
		//List<Vector2> trapesium = _bentukdasar.TrapesiumSikuSiku(400, 100, 80, 40, 30);
		List<Vector2> lingkaran = _bentukdasar.Lingkaran(500, 100, 40);
		//List<Vector2> ellips = _bentukdasar.Ellips(600, 100, 50, 30);

		PutPixelAll(persegi, colorShape);
		PutPixelAll(persegiPanjang, colorShape);
		//PutPixelAll(segitiga, colorShape);
		//PutPixelAll(trapesium, colorShape);
		PutPixelAll(lingkaran, colorShape);
		//PutPixelAll(ellips, colorShape);
	}

	private void PutPixel(float x, float y, Godot.Color? color = null)
	{
		if (x < 0 || y < 0 || x > GetViewportRect().Size.X || y > GetViewportRect().Size.Y)
		{
			GD.PrintErr($"Warning: Titik di luar layar ({x}, {y})");
			return;
		}
		Godot.Color actualColor = color ?? Godot.Colors.White;
		DrawCircle(new Vector2(x, y), 1, actualColor);
	}



	private void PutPixelAll(List<Vector2> dots, Godot.Color? color = null)
	{
		foreach (Vector2 point in dots)
		{
			PutPixel(point.X, point.Y, color);
		}
	}

	public override void _Process(double delta)
	{
		QueueRedraw();
	}
}
