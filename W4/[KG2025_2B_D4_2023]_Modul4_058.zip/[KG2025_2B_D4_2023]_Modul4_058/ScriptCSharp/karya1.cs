namespace Godot;

using Godot;
using System;
using System.Collections.Generic;

public partial class karya1 : Node2D
{
	private primitif _primitif = new primitif();
	private bentukdasar _bentukdasar;
	private const int MarginLeft = 10;
	private const int MarginTop = 10;

	private int WorldOriginX;
	private int WorldOriginY;

	private Transformasi _transformasi = new Transformasi();
	private float[,] _transformMatrix = new float[3, 3];

	public override void _Ready()
	{
		GD.Print("karya1 _Ready() dipanggil");
		_bentukdasar = new bentukdasar();

		if (_bentukdasar == null)
			GD.PrintErr("ERROR: _bentukdasar masih null!");

		WorldOriginX = (int)(GetViewportRect().Size.X / 2);
		WorldOriginY = (int)(GetViewportRect().Size.Y / 2);

		// Inisialisasi matriks transformasi sebagai matriks identitas
		Transformasi.Matrix3x3Identity(_transformMatrix);

		// Contoh penggunaan transformasi
		ApplyTranslation(50, 10); // Translasi
		ApplyScaling(1.5f, 1.5f);  // Scaling
		ApplyRotationClockwise(90); // Rotasi searah jarum jam 45 derajat
		ApplyShearing(0.5f, 0);    // Shearing horizontal

		QueueRedraw();
	}

	public override void _Draw()
	{
		DrawShapes();
	}

	private void DrawShapes()
	{
		Godot.Color colorShape = new Godot.Color("#FF5733");

		// Buat bentuk dasar
		List<Vector2> persegi1 = _bentukdasar.Persegi(WorldOriginX + 20, WorldOriginY - 10, 50);
		List<Vector2> segitiga = _bentukdasar.SegitigaSamaKaki(WorldOriginX - 70, WorldOriginY - 100, 100, 100);
		List<Vector2> lingkaran = _bentukdasar.Lingkaran(WorldOriginX - 100, WorldOriginY + 50, 50);
		List<Vector2> trapesium = _bentukdasar.TrapesiumSikuSiku(WorldOriginX + 100, WorldOriginY + 90, 100, 40, 100);

		// Aplikasikan transformasi
		List<Vector2> transformedPersegi = _transformasi.GetTransformPoint(_transformMatrix, persegi1);
		List<Vector2> transformedSegitiga = _transformasi.GetTransformPoint(_transformMatrix, segitiga);
		List<Vector2> transformedLingkaran = _transformasi.GetTransformPoint(_transformMatrix, lingkaran);
		List<Vector2> transformedTrapesium = _transformasi.GetTransformPoint(_transformMatrix, trapesium);

		// Gambar bentuk yang telah ditransformasi
		PutPixelDotted(transformedPersegi, colorShape);
		PutPixelDotted(transformedSegitiga, colorShape);
		PutPixelDotted(transformedLingkaran, colorShape);
		PutPixelDotted(transformedTrapesium, colorShape);
	}

	private void PutPixel(float x, float y, Godot.Color? color = null)
	{
		if (x < 0 || y < 0 || x > GetViewportRect().Size.X || y > GetViewportRect().Size.Y)
		{
			GD.PrintErr($"Warning: Titik di luar layar ({x}, {y})");
			return;
		}
		Godot.Color actualColor = color ?? Godot.Colors.White;
		DrawCircle(new Vector2(x, y), 1, actualColor);
	}

	private void PutPixelDotted(List<Vector2> dots, Godot.Color? color = null)
	{
		for (int i = 0; i < dots.Count; i += 10) // Hanya menggambar titik-titik dengan selang 2 pixel
		{
			PutPixel(dots[i].X, dots[i].Y, color);
		}
	}

	// Metode-metode transformasi
	private void ApplyTranslation(float x, float y)
	{
		Vector2 coord = new Vector2(0, 0); // Koordinat referensi untuk translasi
		_transformasi.Translation(_transformMatrix, x, y, ref coord);
	}

	private void ApplyScaling(float x, float y)
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik pusat scaling
		_transformasi.Scaling(_transformMatrix, x, y, coord);
	}

	private void ApplyRotationClockwise(float angle)
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik pusat rotasi
		_transformasi.RotationClockwise(_transformMatrix, angle, coord);
	}

	private void ApplyRotationCounterClockwise(float angle)
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik pusat rotasi
		_transformasi.RotationCounterClockwise(_transformMatrix, angle, coord);
	}

	private void ApplyShearing(float x, float y)
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik referensi untuk shearing
		_transformasi.Shearing(_transformMatrix, x, y, coord);
	}

	private void ApplyReflectionToX()
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik referensi untuk refleksi
		_transformasi.ReflectionToX(_transformMatrix, ref coord);
	}

	private void ApplyReflectionToY()
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik referensi untuk refleksi
		_transformasi.ReflectionToY(_transformMatrix, ref coord);
	}

	private void ApplyReflectionToOrigin()
	{
		Vector2 coord = new Vector2(WorldOriginX, WorldOriginY); // Titik referensi untuk refleksi
		_transformasi.ReflectionToOrigin(_transformMatrix, ref coord);
	}
}
